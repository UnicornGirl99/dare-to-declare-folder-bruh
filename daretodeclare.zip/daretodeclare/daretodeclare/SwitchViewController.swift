 //
//  ViewController.swift
//  switches
//
 

import UIKit

class SwitchViewController: UIViewController {
    @IBOutlet weak var Immigraton: UILabel!
    @IBOutlet weak var highlightcolor: UILabel!
    @IBOutlet weak var Climatechange: UILabel!
    @IBOutlet weak var poverty: UILabel!
    @IBOutlet weak var waterfood: UILabel!
   
    @IBAction func switch3on(_ sender: Any) {
        if switch3.isOn {
            poverty.textColor = highlightcolor.textColor
        }
        if !switch3.isOn {
            poverty.textColor = offcolor.textColor
        }
    }
    @IBOutlet weak var switch4: UISwitch!
    @IBAction func switch4on(_ sender: Any) {
        if switch4.isOn {
            waterfood.textColor = highlightcolor.textColor
        }
        if !switch4.isOn {
            waterfood.textColor = offcolor.textColor
        }
    }
    

    @IBOutlet weak var offcolor: UILabel!
    @IBOutlet weak var switch1: UISwitch!
    @IBOutlet weak var switch2: UISwitch!
    @IBOutlet weak var switch3: UISwitch!
    @IBAction func switch2on(_ sender: Any) {
        if switch2.isOn {
            Climatechange.textColor = highlightcolor.textColor
        }
        if !switch2.isOn {
            Climatechange.textColor = offcolor.textColor
        }
    }
    
    @IBAction func switch1on(_ sender: Any) {
        if switch1.isOn {
            Immigraton.textColor = highlightcolor.textColor
        }
        if !switch1.isOn {
            Immigraton.textColor = offcolor.textColor
        }
    
    }
 
 
 
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
 }


